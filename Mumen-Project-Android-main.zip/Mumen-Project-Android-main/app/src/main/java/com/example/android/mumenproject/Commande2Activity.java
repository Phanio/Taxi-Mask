package com.example.android.mumenproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Commande2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commande2);
    }
}